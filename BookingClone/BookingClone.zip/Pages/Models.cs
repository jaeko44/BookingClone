﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace BookingClone.Pages
{
    public class Models
    {
    }


    public class OfferingModel
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public Guid Id { get; set; }
        [Required]
        public string FirstMidName { get; set; }
        [Required]
        public string LastName { get; set; }
    }

    public class BookModel
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public Guid Id { get; set; }
        public string BookingDate { get; set; }
        public string LeaderName { get; set; }
        public GuestDetails GuestDetails { get; set; }
        public string ReferenceNo { get; set; }
        public string HotelConfNo { get; set; }
        public string HotelName { get; set; }
        public string CheckInDate { get; set; }
        public string CheckOutDate { get; set; }
        public int TotalNights { get; set; }
        public string RoomType { get; set; }
        public string Meal { get; set; }
        public int TotalRooms { get; set; }
        public string SpecialComments { get; set; }
        public string Destination { get; set; }
        public string NetRate { get; set; }
        public string CancellationPolicy { get; set; }
        public string OfferingImage { get; set; }


    }
    public class GuestDetails
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public Guid Id { get; set; }
        [Required]
        public string FullName { get; set; }
        public string Address { get; set; }
        [Required]
        public string Email { get; set; }
        public string Gender { get; set; }
        public string DateOfBirth { get; set; }
        public string Nationality { get; set; }
        public string ResidenceCountry { get; set; }
        [Required]
        public string MobileNumber { get; set; }
        public string TravelPurpose { get; set; }
        public string IdentificationNumber { get; set; }
        public Guid BookingOfferId {get; set;}

    }

    public class Image
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public Guid Id { get; set; }
        public string ImageName { get; set; }
        public string ImagePath { get; set; }
        public IFormFile ImageFile { get; set; }
    }


    public class ContactFormModel
    {
        [Required]
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        [Required]
        public string Subject { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Message { get; set; }

    }
}
